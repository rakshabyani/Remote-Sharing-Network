package hello;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.google.gson.Gson;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.sample.DAO.GroupDAO;
import com.sample.DAO.PersonService;
import com.sample.DAO.PostDAO;
import com.sample.DAO.UserService;
import com.sample.DAOImpl.GroupDAOImpl;
import com.sample.DAOImpl.PersonServiceImpl;
import com.sample.DAOImpl.PostDAOImpl;

@ComponentScan
@PropertySource("classpath:configuration.properties")
public class ApplicationConfig extends AbstractMongoConfiguration{

	@Autowired
	private Environment env ;
	
	public GridFsTemplate gridFsTemplate() throws Exception {
		return new GridFsTemplate(mongoDbFactory(), mappingMongoConverter());
	}
 
	@Override
	protected String getDatabaseName() {
		return env.getProperty("dbname");
	}
 
	@Override
	@Bean
	public Mongo mongo() throws Exception {
		return new MongoClient(env.getProperty("db.mongodbHost"));
	}
	
	@Bean
	public MongoDbFactory getMongoDBFactory() throws Exception{
		return new SimpleMongoDbFactory(mongo(),getDatabaseName());
	}
//	public MultipartResolver getMutlipartResolver(){
//		MultipartResolver multipartResolver = new CommonsMultipartResolver();
//		return multipartResolver;
//	}
	@Bean
	public MongoTemplate getMongoTemplate() throws Exception{
		return new MongoTemplate(getMongoDBFactory());
	}
	@Bean
	public FileServices fileService(){
		return new FileServices();
	}
	@Bean
	public GroupDAO getGroupDAO() throws Exception{
		return new GroupDAOImpl();
	}
	@Bean
	public PostDAO getPostDAO(){
		return new PostDAOImpl();
	}
	@Bean UserService getUserService(){
		return new UserService();
	}
	@Bean Gson getGSON(){
		return new Gson();
	}
	@Bean PersonService getPersonService(){
		return new PersonServiceImpl();
	}
}
