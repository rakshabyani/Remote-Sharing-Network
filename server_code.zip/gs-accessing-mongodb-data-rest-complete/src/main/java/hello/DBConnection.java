package hello;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.google.gson.Gson;
import com.sample.Collections.Comment;

public class DBConnection {

	@Autowired @Qualifier("getGSON")
	private Gson gson ;
	public String addPost(JSONObject postJSONObj)
	{
		return null ;
	}
	public String updatePostAddComment(String postId ,JSONObject commentObj)
	{
		
		if(commentObj==null || postId==null || postId.isEmpty())
		{
			return "";
		}
		try{
			Comment comment = gson.fromJson(commentObj.toString(), Comment.class);
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return null ;
	}
}
