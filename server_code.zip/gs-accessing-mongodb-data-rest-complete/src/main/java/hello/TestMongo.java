package hello;

import java.io.FileInputStream;
import java.io.InputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.data.mongodb.gridfs.GridFsOperations;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class TestMongo {

	public static void main(String args[])
	{
		ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		//ApplicationContext context = new GenericXmlApplicationContext("SpringConfig.xml");
		GridFsOperations gridFsOp = (GridFsOperations) context.getBean("gridTemplate");
		FileServices service = (FileServices)context.getBean("fileService");
		service.savefile(null,"");
		
	}
	public void addFile()
	{
		
		DBObject fileMetaData = new BasicDBObject();
		fileMetaData.put("name", "file1.txt");
		try{
			InputStream ip = new FileInputStream("D:/filename.txt");
			//gridFsOp.store(ip,"fileName.txt", fileMetaData);	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
