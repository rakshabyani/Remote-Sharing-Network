package hello;
import java.util.ArrayList;

import com.notnoop.apns.APNS;
import com.notnoop.apns.ApnsService;

public class Notification
{
//	 
	private static ApnsService service = null ;
	
	public Notification(){
		
		if(service==null)
		{
			service = APNS.newService()
			.withCert("C:/intern/pushnotification/PushChatProject/iphone_dev.p12", "RSNsolution")
			.withSandboxDestination()
			.build();
		}
	}
	public void pushMSG(String postId, String msg, ArrayList<String> deviceTokens)
	 
	{
		String payload = APNS.newPayload().alertBody(msg).customField("postId", postId).build();
		//String token = "1e971b973fbe8bec869fb36c7c57e20cbcb5c070b81fa56a59005a98480bb849";
		for(String token:deviceTokens)
		{
			service.push(token, payload);
		}
	}
}
