package hello;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mongodb.WriteResult;
import com.sample.Collections.Comment;
import com.sample.Collections.Person;
import com.sample.Collections.Post;
import com.sample.DAO.PersonService;
import com.sample.DAO.PostDAO;

@RestController
public class UserController {

	private int BUFFER_SIZE = 4096 ;
	@Resource
	private PersonService personService;
	
	@Resource
	private PostDAO postDAO;
	
	@Autowired@Qualifier("getMongoTemplate")
	private MongoOperations mongoOp ;
	
	
	@Autowired
	private FileServices fileService;
	@RequestMapping(value="/user",method=RequestMethod.GET)
    public @ResponseBody String sayHello(@RequestParam(value="name", required=false, defaultValue="Stranger") String name) {
		//return fileService.savefile();
        return "Hi "+name;
    }
	@RequestMapping(value="/download",method=RequestMethod.GET)
	 public  void downloadFileById(@RequestParam(value="fileId") String fileId , HttpServletResponse response) throws IOException
	 {
		String []fileNames = new String[1];
	  InputStream ip = fileService.getFileById(fileId,fileNames);
	  
  		String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename="+fileNames[0]); 
        response.setHeader(headerKey, headerValue);
 
        // get output stream of the response
        OutputStream outStream = response.getOutputStream();
 
        byte[] buffer = new byte[BUFFER_SIZE];
        int bytesRead = -1;
        response.setContentType("");
        while ((bytesRead = ip.read(buffer)) != -1) {
            outStream.write(buffer, 0, bytesRead);
        }
 
        ip.close();
        outStream.close();
	  
	 }
	
	
	 @RequestMapping(value="/upload", method=RequestMethod.GET)
	    public @ResponseBody String provideUploadInfo() {
	        return "You can upload a file by posting to this same URL.";
	    }
	// updatePostAddFile
	 // /uploadFile
	 @RequestMapping(value="/uploadFileForPost", method=RequestMethod.POST)
	    public @ResponseBody String saveFileToDB(@RequestParam("name") String name,@RequestParam("postId") String postId ,
	            @RequestParam("file") MultipartFile file){
		 	if(postId!=null && !postId.isEmpty())
			{
				// upload file .
		 		if (file!=null && !file.isEmpty()) 
		        {
		            try 
		            
		            {                                                                                                
		            	long start = System.currentTimeMillis();
		            	String fileId = fileService.savefile(file.getInputStream(),name);
		            	long end = System.currentTimeMillis();
		            	System.out.println((end-start)/1000);
		            	// check for id 
		            	if(fileId!=null && !fileId.isEmpty())
		            	{
		            		
		            		WriteResult result = mongoOp.updateFirst(new Query(Criteria.where("id").is(postId)), 
		            				new Update().push("fileid", fileId),Post.class);
		            		// update Post collection , add this file Id 
			            	// REF : update post with comments 
			               
			                
		            	}
		            	else 
		            	{
		            		return "file empty";
		            	}
		            		
		            	System.out.println("uploaded");
		                return "successfully uploaded the file : "+name;	
		            } 
		            catch (Exception e) 
		            {
		                return "Error occrred in uploading file - "+name+": "+ e.getMessage();
		            }
		        } 
		        else 
		        {
		            return "upload failed";
		        }
			}
	        return "";
	    }
	 
	 
	 @RequestMapping(value="/posts", method=RequestMethod.GET)
	  public @ResponseBody String getAllPosts(@RequestParam(value="userName")String userName) {
	   JSONArray postArr = postDAO.getAll(userName);
	   return postArr.toString();
	  }
	 @RequestMapping(value="/add/device", method=RequestMethod.POST)
	 public @ResponseBody String addDeviceForUser(@RequestBody String updateStr) {
		JSONObject obj = new JSONObject(updateStr);
		String userName = obj.getString("userName");
		String deviceID = obj.getString("deviceID");
		return personService.addDevice(userName,deviceID);
	 }
	 
	 
	 @RequestMapping(value="/remove/device", method=RequestMethod.POST)
	 public @ResponseBody String removeDeviceForUser(@RequestBody String inputJson){
		 JSONObject obj = new JSONObject(inputJson);
			String userName = obj.getString("userName");
			String deviceID = obj.getString("deviceID");
		 return personService.removeUser(userName,deviceID);
	 }
	 
	 
	 @RequestMapping(value="/comments/post", method=RequestMethod.GET)
	  public @ResponseBody List<Comment> getAllCommentsByPost(@RequestParam(value="id") String postId) {
	   return postDAO.get(postId);
	  }
	 
	 @RequestMapping(value="/posts/person", method=RequestMethod.GET)
		public @ResponseBody String getAllPostsByUser(@RequestParam(value="userName") String userNames) {
		JSONArray postArr =postDAO.getAllPostsOfUser(userNames);
		return postArr.toString();
		}
		
	
		@RequestMapping(value="/add/person", method=RequestMethod.POST)
		public @ResponseBody Boolean addUser(@RequestBody String personstr) {
			JSONObject obj = new JSONObject(personstr);
			Person person = new Person() ;
			person.setUserName(obj.getString("userName"));
			person.setFirstName(obj.getString("firstName"));
			person.setLastName(obj.getString("lastName"));
			person.setPassword(obj.getString("password"));
			ArrayList<String> contactid = new ArrayList<String>();
			contactid.add(obj.getString("contacts"));
			ArrayList<String> deviceids = new ArrayList<String>();
			String deviceId = obj.getString("deviceID");
			deviceids.add(deviceId);
			person.setDeviceID(deviceids);
			person.setContacts(contactid);
			if(personService.add(person))
			return true;
		else
			return false;
		
		}
		
		@RequestMapping(value="/add/post", method=RequestMethod.POST)
		public @ResponseBody String addPosts(@RequestBody Post post)
		{
				//System.out.println(post);
				if(post==null)
					return "";
				//post.setDate(new Date());
				String postId = postDAO.add(post);
				String userNames=post.getUserName();
				ArrayList<String> deviceIdList ;
				ArrayList<String> contactList = postDAO.getAllContacts(userNames);
				if(contactList!=null)
				{
					for(String user:contactList)
					{
						deviceIdList = postDAO.getDeviceId(user);					
						Notification PushNotification= new Notification();
						PushNotification.pushMSG(postId,"You have received a Post",deviceIdList);
					}
				}
				
				// take user id , get contacts of that user , 
				// for each user , get registered device id , and call post notification method
			return postId ;	
		}
		
		@RequestMapping(value="/add/comment", method=RequestMethod.POST)
		public @ResponseBody String addComment(@RequestBody String commentStr) {
			JSONObject obj = new JSONObject(commentStr);
			String postId = obj.getString("postid");
			Comment comment = new Comment() ;
			comment.setUserName(obj.getString("userName"));
			comment.setCommentText(obj.getString("commentText"));
			postDAO.updatePostAddComment(postId,comment);
			return postId;
			
		}
	
}
