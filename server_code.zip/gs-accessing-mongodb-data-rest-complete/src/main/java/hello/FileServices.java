package hello;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSFile;

@Service
public class FileServices {
	@Autowired /*@Qualifier("gridFsTemplate")*/
	 private GridFsTemplate gridFsOp;	
	
	
	public String savefile(InputStream inputStream,String fileName){
		
		DBObject fileMetaData = new BasicDBObject();
		String fileId = "";
		fileMetaData.put("name", "file1.txt");
		try{
			GridFSFile file = gridFsOp.store(inputStream,fileName, fileMetaData);
			fileId = file.getId().toString();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return fileId ;
	}
	public InputStream getFileById(String fileId,String []fileNames)
	{
		if(fileId==null || fileId.length()<=0)
		{
			return null ;
		}
		fileId = fileId.replace("\"", "");
		fileId = fileId.replace("\'", "");
		try{
			 GridFSDBFile gridDBFile = gridFsOp.findOne(new Query(Criteria.where("_id").is(new ObjectId(fileId))));
			 String fileName = gridDBFile.getFilename();
			 fileNames[0] = fileName ;
			InputStream ip = gridDBFile.getInputStream();
			if(ip!=null)
				return ip ;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null ;
	}
	public String getFileNameFromId(String fileId)
	{
		String fileName = "";
		try{
			GridFSDBFile gridDBFile = gridFsOp.findOne(new Query(Criteria.where("_id").is(new ObjectId(fileId))));
			fileName = gridDBFile.getFilename();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return fileName ;
	}
}


/*Here the code snippets for file upload to MongoDB GridFS:
File anyFile = new File();
String fileName = anyFile.getName();
GridFS gfsFileType = new GridFS(, );
GridFSInputFile gfsFile = gfsFileType.createFile(anyFile);
gfsFile.setFilename(fileName);
gfsFile.save();


and the code snippet for downloading a GridFSDBFile back to the client:
 
GridFS gfsFileType = new GridFS(, );
GridFSDBFile fileOut = gfsFile.findOne(new ObjectId());
response.setContentType();
InputStream is = fileOut.getInputStream();
int read = 0;
byte[] bytes = new byte[1024];
OutputStream os = response.getOutputStream();
while((read = is.read(bytes)) != -1) {
os.write(bytes, 0, read);
}
os.flush();
os.close();
*/
 
