package com.RNS.UT;

import hello.ApplicationConfig;




import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sample.Collections.Comment;
import com.sample.Collections.Post;
import com.sample.DAO.PersonService;
import com.sample.DAO.PostDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={ApplicationConfig.class})
public class RNSTesting {

	@Autowired
	private PostDAO postDAo;
	
	@Autowired @Qualifier("getPersonService")
	private PersonService personService ;
	
	/*@Test
	public void someTestMethod(){
		
	}
	
	@Test
	public void userSaveTest(){
		
		Assert.assertEquals(false, personService.add(null));
	}*/
	@Test
	public void AddPostTest()
	{
		Post post = new Post();
		//post.setPostText("unit testing");
		Assert.assertNotNull(postDAo.addPost(post));
		System.out.println(post);
	}
	@Test
	public void AddCommentsToPostTest()
	{
		Comment comment = new Comment();
		comment.setCommentText("sample comment text");
		comment.setUserName("raksha");
		
		Comment comment1 = new Comment();
		comment1.setCommentText("sample comment text");
		comment1.setUserName("nikita");
		
		Comment comment2 = new Comment();
		comment2.setCommentText("sample comment text");
		comment2.setUserName("sheena");
		Comment []comments = new Comment[3];
		comments[0]= comment ;
		comments[1]= comment1 ;
		comments[2]= comment2 ;
		
		Assert.assertNotNull(postDAo.updatePostAddComment("55081cc07534ff86c96f52a5", comment));
		
		//Assert.assertNotNull(postDAo.updatePostAddComments("", comments));
	}
}
