package com.sample.DAO;

import com.sample.Collections.UserGroup;

public interface GroupDAO {

	public int createGroup(UserGroup userGroup);
}
