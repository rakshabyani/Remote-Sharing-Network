package com.sample.DAO;

import org.springframework.beans.factory.annotation.Autowired;

import com.google.gson.Gson;
import com.sample.Collections.UserGroup;
import com.sample.DAO.GroupDAO;

public class UserService {

	@Autowired
	private GroupDAO groupDao ;
	@Autowired
	private Gson gson ;
	public int saveUserGroup(String uGroupStr)
	{
		if(uGroupStr==null || uGroupStr.length()<=0)
			return 0 ;
		UserGroup uGroup = gson.fromJson(uGroupStr, UserGroup.class);
		groupDao.createGroup(uGroup);
		return 0 ;
	}
}
