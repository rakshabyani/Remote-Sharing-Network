package com.sample.DAO;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.springframework.web.multipart.MultipartFile;

import com.sample.Collections.Comment;
import com.sample.Collections.Person;
import com.sample.Collections.Post;

public interface PostDAO {
	
	public String add(Post post);
	public String addPost(Post post);
	
	public String updatePostAddComment(String postId , Comment comment);
	public String updatePostAddComments(String postId,Comment[] comments);
	public ArrayList<String> getAllContacts(String userNames);
	public ArrayList<String> getDeviceId(String userNames);
	public JSONArray getAll(String userName);
	public List<Comment> get(String postId);
	public JSONArray getAllPostsOfUser(String userNames);
	
	
	
}
