package com.sample.DAO;


import java.util.List;

import com.sample.Collections.Person;
import com.sample.Collections.Post;

public interface PersonService {

	public String addPerson(Person person);
	public Boolean add(Person person);
	public Boolean delete(String id);
	public String removeUser(String userName, String deviceId);
	public String addDevice(String userNames, String deviceId);

}
