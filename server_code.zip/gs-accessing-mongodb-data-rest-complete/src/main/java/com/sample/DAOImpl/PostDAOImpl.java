package com.sample.DAOImpl;

import hello.FileServices;

import java.security.Permissions;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.mongodb.WriteResult;
import com.sample.Collections.Comment;
import com.sample.Collections.Person;
import com.sample.Collections.Post;
import com.sample.DAO.PostDAO;

public class PostDAOImpl implements PostDAO{
	
	@Autowired@Qualifier("getMongoTemplate")
	private MongoOperations mongoOp ;
	@Autowired @Qualifier("getGSON")
	private Gson gson ;
	
	@Autowired
	private FileServices fileService ;
	
	@Override
	public ArrayList<String> getAllContacts(String userNames)
	{
		Query query=new Query();
		query.addCriteria(Criteria.where("userName").is(userNames));
		Person persons=mongoOp.findOne(query,Person.class);
		if(persons==null)
			return null ;
		return persons.getContacts();
	}
	 
	 public JSONArray getAll(String userNames)
	 {
		 Query query=new Query();
		 query.addCriteria(Criteria.where("userName").is(userNames));
		  query.fields().include("postText");
		  query.fields().include("userName");
		  query.fields().include("fileid");
		  //List<Post> post = (List<Post>) mongoOp.findAll(query,Post.class);
		 JSONArray postArr = new JSONArray();
	    List<Post> posts = mongoOp.find(query,Post.class);
	    if(posts!=null)
	    {
	    	Iterator<Post> it = posts.iterator();
	    	while(it.hasNext())
	    	{
	    		Post post = it.next();
	    		String jsonPost = gson.toJson(post,Post.class);
	    		
	    		JSONObject postObj = new JSONObject(jsonPost);
	    		postObj.remove("fileid");
	    		JSONArray filesArr = new JSONArray();
	    		ArrayList<String> fileIds = post.getFileid();
	    		
	    		if(fileIds!=null){
	    			for(String fileId : fileIds)
		    		{
		    			String fileName = fileService.getFileNameFromId(fileId);
		    			JSONObject fileObj = new JSONObject();
		    			fileObj.put("fileId", fileId);
		    			fileObj.put("fileName", fileName);
		    			
		    			filesArr.put(fileObj);
		    		}
		    		postObj.put("files", filesArr);	
	    		}
	    		
	    		
	    		
	    		postArr.put(postObj);
	    	}
	    	
	    }
	    
	    // file name
//	     without comments , restrict
	    return postArr;
	 }
	 
	 public List<Comment> get(String postid) {
		  Query query=new Query();
		  query.addCriteria(Criteria.where("id").is(postid));
		  query.fields().include("comments");
		  Post post =  mongoOp.findOne(query,Post.class);
		    return post.getComments();
		   }
	 
	@Override
	public ArrayList<String> getDeviceId(String userNames)
	{
		Query query=new Query();
		query.addCriteria(Criteria.where("userName").is(userNames));
		Person persons=mongoOp.findOne(query,Person.class);
		return persons.getDeviceID();
	}
	@Override
	public String addPost(Post post) {
		mongoOp.save(post);
		return post.getId();
	}
	
	public String add(Post post) {

		String retId = "";
		try {
			if(post.getId()==null || post.getId().length()==0)
				post.setId(UUID.randomUUID().toString());
			   mongoOp.save(post);
			   retId = post.getId();
			   
		  } catch (Exception e) {
			  e.printStackTrace();
		  }
		return retId ;
		
	}
	


	@Override
	public String updatePostAddComment(String postId, Comment comment) {
		
		if(postId==null || postId.isEmpty())
		{
			return "failure";
		}
		
//		WriteResult result = mongoOp.updateFirst(Query.query(Criteria.where("id").is(postId)), 
//				new Update().push("comments", comment), Comment.class);
		WriteResult result = mongoOp.updateFirst(new Query(Criteria.where("id").is(postId)), 
				new Update().push("comments", comment),Post.class);
		return "true";
	}
	


	@Override
	public String updatePostAddComments(String postId,
			Comment[] comments) {
		if(postId==null || postId.isEmpty())
			return "";
		WriteResult result = mongoOp.updateFirst(new Query(Criteria.where("id").is(postId)), new Update().pushAll("comments", comments), Post.class);
		return result.getUpsertedId().toString();
	}

	
	// get posts related to the user
	public JSONArray getAllPostsOfUser(String userNames)
	{
		JSONArray postArr = new JSONArray();
		ArrayList<String> contacts= getAllContacts(userNames);
		contacts.add(userNames);
		for(String user: contacts)
		{
				List<Post> posts = mongoOp.find(new Query(Criteria.where("userName").is(user)),Post.class);
			    if(posts!=null)
			    {
			    	Iterator<Post> it = posts.iterator();
			    	while(it.hasNext())
			    	{
			    		Post post = it.next();
			    		String jsonPost = gson.toJson(post,Post.class);
			    		
			    		JSONObject postObj = new JSONObject(jsonPost);
			    		postObj.remove("fileid");
			    		JSONArray filesArr = new JSONArray();
			    		ArrayList<String> fileIds = post.getFileid();
			    		
			    		if(fileIds!=null)
			    		{
			    			for(String fileId : fileIds)
				    		{
				    			String fileName = fileService.getFileNameFromId(fileId);
				    			JSONObject fileObj = new JSONObject();
				    			fileObj.put("fileId", fileId);
				    			fileObj.put("fileName", fileName);
				    			
				    			filesArr.put(fileObj);
				    		}
				    		postObj.put("files", filesArr);	
			    		}
			    		
			    		
			    		postArr.put(postObj);
			    	}
			    	
			    }
		}
			    
	return postArr;
}
		
		
	// 1. get contacts - Array of user names 
	// 2. Query 
//	Query query=new Query();
//	Criteria cri = new Criteria();
	//query.addCriteria(cri);
	// cri.in(contactList)
	// List<Post> posts = mongoOp.find(query, Post.class)
	

	
}
