package com.sample.DAOImpl;





import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mongodb.WriteResult;
import com.sample.Collections.Person;
import com.sample.Collections.Post;
import com.sample.DAO.PersonService;

@Service("personService")
@Transactional
public class PersonServiceImpl implements PersonService {

		//private PersonRepository personRepository;
	// use mongo template 
	// write update /save code get 
	@Autowired@Qualifier("getMongoTemplate")
	private MongoOperations mongoOp ;
	
	
	/* public List<Person> getAll() {
	        List<Person> person = mongoOp.findAll(person);
	        return person;
	    }*/
	@Override
	public String addPerson(Person person) {
		mongoOp.save(person);
		return person.getId();
	}
		
	public Boolean add(Person person) {
		
		try {
			if(person==null)
			{
				return false ;
			}
			
			mongoOp.save(person);
			return true;
		  } catch (Exception e) {
			  e.printStackTrace();
			  return false;
		  }
	}
	
	

	public Boolean delete(String id) {
			try {
				//mongoOp.delete(id);
	            return true;
			  } catch (Exception e) {
				  e.printStackTrace();
				  return false;
			  }
		}

		
	public String removeUser(String userName, String deviceId)
	{

		Query query=new Query();
		query.addCriteria(Criteria.where("userName").is(userName));
		query.addCriteria(Criteria.where("deviceID").is(deviceId));
		 mongoOp.updateFirst(query, new Update().pull("deviceID",deviceId),Person.class);
		return null;
	}
	
	@Override
	public String addDevice(String userNames, String deviceId){
		 WriteResult result= mongoOp.updateFirst(new Query(Criteria.where("userName").is(userNames)), 
					new Update().push("deviceID",deviceId),Person.class);
		 return result.getUpsertedId().toString();
	}

}
