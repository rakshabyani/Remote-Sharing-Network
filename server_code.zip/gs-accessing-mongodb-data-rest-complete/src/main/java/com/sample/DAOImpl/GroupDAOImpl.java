package com.sample.DAOImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoOperations;

import com.sample.Collections.UserGroup;
import com.sample.DAO.GroupDAO;

public class GroupDAOImpl implements GroupDAO{

	@Autowired@Qualifier("getMongoTemplate")
	private MongoOperations mongoOp ;
	
	public GroupDAOImpl(/*MongoOperations mongoOp*/)
	{
		//this.mongoOp = mongoOp;
	}
	@Override
	public int createGroup(UserGroup userGroup) {
		
		mongoOp.save(userGroup);
		return 0;
	}

}
