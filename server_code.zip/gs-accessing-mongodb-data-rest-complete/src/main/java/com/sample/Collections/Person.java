package com.sample.Collections;


import java.util.ArrayList;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.supercsv.cellprocessor.constraint.Unique;

public class Person {

	@Id private String id;

	
	private String firstName;
	private String lastName;
	@Indexed
	private String userName;
	private String password;
	private ArrayList<String> deviceID;
	private ArrayList<String> contacts ;
	public ArrayList<String> getContacts() {
		return contacts;
	}
	public void setContacts(ArrayList<String> contacts) {
		this.contacts = contacts;
	}
	public String getId(){
		return id;
	}
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public ArrayList<String> getDeviceID() {
		return deviceID;
	}
	public void setDeviceID(ArrayList<String> deviceID) {
		this.deviceID = deviceID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
