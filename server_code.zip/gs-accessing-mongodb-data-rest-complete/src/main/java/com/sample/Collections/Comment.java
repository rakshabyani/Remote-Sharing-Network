package com.sample.Collections;

import org.springframework.data.mongodb.core.mapping.DBRef;

public class Comment {

	private String commentText ;
	private String userName ;
	// date time 
	public String getCommentText() {
		return commentText;
	}
	public void setCommentText(String commentText) {
		this.commentText = commentText;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String person) {
		this.userName = person;
	}
}
