package com.sample.Collections;

//import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;

public class Post {

	@Id
	private String id ;
	private String postText ;
	private Date date;
	public Post(String postText,String userName) {
		super();
		this.postText = postText;
		this.date = new Date();
		this.userName = userName;
	}
	
	public Post(){
		
	}
	//@DBRef
	private String userName ;
	private ArrayList<Comment> comments ;
	
	private ArrayList<String> fileid;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPostText() {
		return postText;
	}
	public void setPostText(String postText) {
		this.postText = postText;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String person) {
		this.userName = person;
	}
	public ArrayList<Comment> getComments() {
		return comments;
	}
	public void setComments(ArrayList<Comment> comments) {
		this.comments = comments;
	}
	public ArrayList<String> getFileid() {
		return fileid;
	}
	public void setFileid(ArrayList<String> fileid) {
		this.fileid = fileid;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = new Date();
	}
	
}
