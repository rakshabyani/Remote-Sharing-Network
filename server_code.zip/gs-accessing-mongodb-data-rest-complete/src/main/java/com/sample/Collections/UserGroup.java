package com.sample.Collections;

import java.util.ArrayList;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;

public class UserGroup {

	@Id 
	private String id ;
	private String groupName ;
	@DBRef
	private ArrayList<String> userIds;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getGroupName() {
		return groupName;
	}
	public ArrayList<String> getUserIds() {
		return userIds;
	}
	public void setUserIds(ArrayList<String> userIds) {
		this.userIds = userIds;
	}
}
