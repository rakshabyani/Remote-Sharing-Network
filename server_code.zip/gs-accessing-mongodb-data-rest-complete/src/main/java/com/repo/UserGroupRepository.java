package com.repo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.sample.Collections.UserGroup;

@RepositoryRestResource(collectionResourceRel = "usergroup", path = "usergroup")
public interface UserGroupRepository extends MongoRepository<UserGroup, String>{
	
	@Query("{id:?0}")
	public List<String> findAllGroupsByGroupId(@Param("id") String id);
	
	
}

