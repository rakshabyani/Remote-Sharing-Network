package com.repo;


import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.sample.Collections.Person;
import com.sample.Collections.Post;

@RepositoryRestResource(collectionResourceRel = "post", path = "post")
public interface PostRepository extends MongoRepository<Post, String>{
	
	
	Person person=new Person();
	List<String> contacts=person.getContacts();
	@Query(value="{'contacts':?0}")
	public List<String> getAllPosts(@Param("contacts") List<String> contact1);

	@Query(value="{'userName': ?0}",fields="{'postText':1,'comments':1}")
	public List<Post> findAllPostsByUserName(@Param("userName")String name);
	

}










