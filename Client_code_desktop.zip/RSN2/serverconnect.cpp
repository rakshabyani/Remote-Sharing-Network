#include "serverconnect.h"
#include "ui_mainwindow.h"

#include <iostream>


Server::Server()

{


  manager = new QNetworkAccessManager(this);
  request.setUrl(QUrl("http://10.20.4.234:8080/user"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "text/xml");
    reply= manager->get(request);
    QObject::connect(manager, SIGNAL(finished(QNetworkReply *)),
                     SLOT(slotRequestFinished(QNetworkReply *)));


 // connect(reply, SIGNAL(downloadProgress(qint64,qint64)),
                //     SLOT(slotSetProgress(qint64,qint64)));

}

Server :: ~Server()
{

}

void Server::slotRequestFinished(QNetworkReply *reply)
{

    if (reply->error() > 0) {


      std::cout <<"\nerror reason:" <<reply->errorString().toStdString();
        mServerStatus->setText(reply->errorString());
       mServerStatus->setText("Error number = " + reply->errorString());
    }
    else {
      mServerStatus->setText("connected");
    }
}

void Server::slotSetProgress(qint64 received, qint64 total)
{

}
