#ifndef CREATEGROUP_H
#define CREATEGROUP_H

#include <QWidget>
#include "ui_creategroup.h"
#include <QCheckBox>
#include <QtNetwork/QtNetwork>



class creategroup : public QWidget, public Ui_creategroup
{
    Q_OBJECT

public:
    creategroup();
    ~creategroup();

private:
    QWidget* widget;
    void Displayusers();
    QNetworkAccessManager* mUserContactManager;
    QByteArray uContacts;
    int usize;
    int contactflag;
    std::vector<QCheckBox*> mCheckBoxes;
private slots:
    virtual void new_grp_create();
    virtual void slotcontactFinished(QNetworkReply *);

};

#endif // CREATEGROUP_H
