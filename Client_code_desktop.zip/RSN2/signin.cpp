
#include "signin.h"
#include <QFileDialog>
#include "ui_uploadwidget.h"
#include "mainwindow.h"
#include <iostream>
#include "group.h"

SigninWindow::SigninWindow(QWidget *parent)
{

    setupUi(this);
    connect(upload_btn, SIGNAL(clicked()), this, SLOT(upload_btn_clicked()));
    connect(sign_back,SIGNAL(clicked()),this,SLOT(signin_close()));
    connect(group_button, SIGNAL(clicked()), this, SLOT(group_button_clicked()));
    connect(mPostDetailsWidget, SIGNAL(cellClicked(int,int)), this, SLOT(DataSelected(int, int)));
    connect(sign_out,SIGNAL(clicked()),this,SLOT(signin_close()));
    connect(refresh_btn,SIGNAL(clicked()),this,SLOT(refresh_btn_clicked()));
    DisplayPosts();

}



SigninWindow::~SigninWindow()
{

}

void SigninWindow::upload_btn_clicked()
{
    mUploadWindow = new UploadWindow();
    mUploadWindow->show();
}


//void SigninWindow::SetSelectedImagePath(QString path)
//{
//    mImagePath = path;
//    mImageThumbnail->setPixmap(QPixmap(path));
//    mImageThumbnail->setScaledContents(true);
//}

void SigninWindow::ReleaseMemory()
{
    if (mUploadWindow)
    {
        ListnerSubject::getInstance()->detach();
        delete mUploadWindow;
        mUploadWindow = NULL;
    }
}

//void SigninWindow::SetImageComment(const QString &image_comment)
//{
//    mPostText->setText(image_comment);
//    mImageComment = image_comment;
//}

void SigninWindow::DataSelected(int row, int col)
{
   // QWidget* wid = mPostDetailsWidget->cellWidget(row, col);
    std::cout <<"\nrow number..."<<row;
    if (row < cursize)
    {
        //UserPosts *obj = new UserPosts(row,mImageComment,mImagePath,MainWindow::getInstance()->postdetails);
        UserPosts *obj = new UserPosts(row,MainWindow::getInstance()->postdetails);
        AddToOpenedWidgets(obj);
        obj->show();
    }
//    else
//    {
//        MainWindow:: getInstance()->flag == -1;
//        MainWindow::getInstance()->getOldPosts();
//    }
}
void SigninWindow::DisplayPosts(){
    //int y = 0;

    QFont f( "Comic Sans MS", 9, QFont::Bold);
    QFont n( "Comic Sans MS", 9, QFont::Normal);


    QJsonDocument jSonDoc(QJsonDocument::fromJson(MainWindow::getInstance()->postdetails));
    qDebug()<<"\n\n\n\n\n\n"<<jSonDoc;

    QJsonArray jArray = jSonDoc.array();
    int size = jArray.size();
    cursize = size;

    QJsonObject jObject;
    mPostDetailsWidget->resizeColumnsToContents();
    mPostDetailsWidget->setAlternatingRowColors(true);
    mPostDetailsWidget->setRowCount(size);
    mPostDetailsWidget->setColumnCount(1);
    mPostDetailsWidget->setColumnWidth(0, mPostDetailsWidget->width());
    for (int i = 0; i < size; ++i)
    {
        int x=10;
        int y=10;
        int width=100, height = 20 ;
        jObject = jArray[i].toObject();
        QWidget* post1 = new QWidget();
        post1->setObjectName(QStringLiteral("post1"));
        post1->setGeometry(QRect(20, 50, 161, 111));
        QLabel* mName = new QLabel(post1);
        mName->setFont( f);
        mName->setObjectName(QStringLiteral("mUserName"));
        mName->setGeometry(QRect(x, y, width, height));
        mName->setText("User Name :");
        QLabel* mUserName = new QLabel(post1);
        mUserName->setFont( n);
        mUserName->setObjectName(QStringLiteral("mUserName"));
        mUserName->setGeometry(QRect(x+width+1, y, width, height));
        mUserName->setText(jObject["userName"].toString());
        QLabel* mPost= new QLabel(post1);
        mPost->setFont( f);
        mPost->setObjectName(QStringLiteral("mPName"));
        mPost->setGeometry(QRect(x, y += height+1 , width, height));
        mPost->setText("Post Text :");
        QLabel* mPostText = new QLabel(post1);
        mPostText->setFont( n);
        mPostText->setObjectName(QStringLiteral("mPostText"));
        mPostText->setGeometry(QRect(x+width+1, y, 219, height));
        mPostText->setText(jObject["postText"].toString());
        QJsonArray array = jObject["files"].toArray();
        for(int fsize=0;fsize<array.size();++fsize)
        {
            QLabel* mFile= new QLabel(post1);
            mFile->setFont( f);
            mFile->setObjectName(QStringLiteral("mFName"));
            mFile->setGeometry(QRect(x, y+= (height+1), width, height));
            mFile->setText("File Name :");
            QLabel* mPostData = new QLabel(post1);
            mPostData->setObjectName(QStringLiteral("mPostData"));
            mPostData->setGeometry(QRect(x+width+1, y, width, height));
            QJsonObject obj = array[fsize].toObject();
            mPostData->setFont( n);
            mPostData->setText(obj["fileName"].toString());
        }
        QLabel* date = new QLabel(post1);
        date->setFont( f);
        date->setObjectName(QStringLiteral("mDate"));
        date->setGeometry(QRect(x, y+= (height+1), width, height));
        date->setText("Date :");
        QLabel* pdate = new QLabel(post1);
        pdate->setFont( n);
        pdate->setObjectName(QStringLiteral("mPDate"));
        pdate->setGeometry(QRect(x+width+1, y, width+40, height));
        pdate->setText(jObject["date"].toString());

        post1->raise();
        mPostDetailsWidget->setRowHeight(i, post1->height());
        mPostDetailsWidget->setCellWidget(i, 0, post1);

    }
//     mPostDetailsWidget->insertRow(cursize);
////     QWidget* post2 = new QWidget();
////     post1->setObjectName(QStringLiteral("post1"));
////     post1->setGeometry(QRect(20, 50, 161, 50));
//     QLabel* xyz = new QLabel();
//     QFont a( "Arial", 12, QFont::Bold);
//     xyz->setObjectName(QStringLiteral("loadMore"));
//     xyz->setGeometry(QRect(10, 10, 100, 20));
//     xyz->setFont(a);
//     xyz->setAlignment(Qt::AlignHCenter);
//     xyz->setText("Load Old Posts");
//     mPostDetailsWidget->setRowHeight(cursize, xyz->height());
//     mPostDetailsWidget->setCellWidget(cursize, 0, xyz);

}

//void SigninWindow::UpdatePosts()
//{

//    int x=10;
//    int y=10;
//    int width=100, height = 20 ;
//    QFont f( "Arial", 10, QFont::Bold);
//    mPostDetailsWidget->insertRow(cursize);
//    QWidget* post2 = new QWidget();
//    post2->setObjectName(QStringLiteral("post2"));
//    post2->setGeometry(QRect(20, 50, 161, 111));

//    QLabel* mName = new QLabel(post2);
//    mName->setFont( f);
//    mName->setObjectName(QStringLiteral("mUserName"));
//    mName->setGeometry(QRect(x, y, width, height));
//    mName->setText("User Name :");
//    QLabel* mUserName = new QLabel(post2);
//    mUserName->setFont( f);
//    mUserName->setObjectName(QStringLiteral("mUserName"));
//    mUserName->setGeometry(QRect(x+width+1, y, width, height));
//    mUserName->setText(MainWindow::getInstance()->GetCurrentUserName());

//    QLabel* mPost= new QLabel(post2);
//    mPost->setFont( f);
//    mPost->setObjectName(QStringLiteral("mPName"));
//    mPost->setGeometry(QRect(x, y += height+1 , width, height));
//    mPost->setText("Post Text :");
//    QLabel* mPostText = new QLabel(post2);
//    mPostText->setFont( f);
//    mPostText->setObjectName(QStringLiteral("mPostText"));
//    mPostText->setGeometry(QRect(x+width+1, y, width, height));
//    mPostText->setText(mImageComment);

//    QLabel* mFile= new QLabel(post2);
//    mFile->setFont( f);
//    mFile->setObjectName(QStringLiteral("mFName"));
//    mFile->setGeometry(QRect(x, y+= (height+1), width, height));
//    mFile->setText("File Name :");
//    QLabel* mPostData = new QLabel(post2);
//    mPostData->setObjectName(QStringLiteral("mPostData"));
//    mPostData->setGeometry(QRect(x+width+1, y, width, height));
//    QFileInfo fname(mImagePath);
//    mPostData->setText(fname.fileName());
//    mPostDetailsWidget->setRowHeight(cursize, 111);
//    mPostDetailsWidget->setCellWidget(cursize, 0, post2);

//}
void SigninWindow::  senddetails(QString pt, QString fn){
    mImagePath = fn;
    mImageComment = pt;
}

void SigninWindow::group_button_clicked(){
    Group* object = new Group() ;
    AddToOpenedWidgets(object);
    object->show();
}

void SigninWindow::signin_close(){
    for (unsigned int i = 0; i < mOpenedWidgets.size(); ++i)
        {
            mOpenedWidgets.at(i)->close();
        }
    this->close();
    MainWindow::getInstance()->show();
}

void SigninWindow::refresh_btn_clicked(){
    MainWindow::getInstance()->flag =1;
    MainWindow::getInstance()->connectToServer();
}
void SigninWindow::AddToOpenedWidgets(QWidget *widget)
{
    mOpenedWidgets.push_back(widget);
}
