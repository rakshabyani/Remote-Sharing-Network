#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <iostream>


#include <QJsonObject>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    flag = 0;
    connect(ui->signup_btn, SIGNAL(clicked()), this, SLOT(signup_btn_clicked()));
    connect(ui->signin_btn, SIGNAL(clicked()), this, SLOT(signin_btn_clicked()));
   // connect(ui->close, SIGNAL(clicked()), this, SLOT(on_close_clicked()));
    mainUrl = "http://192.168.97.1:8080";
    ui->mPassword->setEchoMode(QLineEdit ::Password);
    mNewtworkManager = new QNetworkAccessManager(this);
    mSignInNetworkManger = new QNetworkAccessManager(this);
    connect(mSignInNetworkManger, SIGNAL(finished(QNetworkReply *)),
                    SLOT(slotpostrequest(QNetworkReply*)));
    connect(mNewtworkManager, SIGNAL(finished(QNetworkReply *)),
                    SLOT(slotRequestFinished(QNetworkReply *)));
}


MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow ::checksign()
{
    QJsonObject obj;
    obj ["userName"] = mCurrentUserName;
    obj ["password"] = ui->mPassword->text();
    QJsonDocument saveDoc(obj);
    QUrl serviceurl = QUrl(mainUrl + "/logincheck");//send password :P
    QNetworkRequest p_request(serviceurl);
    p_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    mNewtworkManager->post(p_request,saveDoc.toJson());

}

void MainWindow::signin_btn_clicked()
{
    mCurrentUserName = ui->mUserName->text();
    mCurrentPassword = ui->mPassword->text();
    checksign();
    ui->mUserName->clear();
    ui->mPassword->clear();
   // SigninWindow::getInstance()->SetListnerSubject(&mListnerSubject);
   // UserPosts *obj = new UserPosts();
   // obj->show();
    //mSignInWin.show();
}


void MainWindow::signup_btn_clicked()
{
    mSignUpWin.show();
    //SignupWindow* window = new SignupWindow();
    //window->show();
}

//void MainWindow::on_close_clicked()
//{
//    qApp->quit();
//}

void MainWindow::slotpostrequest(QNetworkReply *reply)
{
    if (reply->error() > 0)
    {


      std::cout <<"\nerror reason:" <<reply->errorString().toStdString();
       // ui->mServerStatus->setText(reply->errorString());
     //  m_label->setText("Error number = " + reply->errorString());
    }
    else
    {
        std::cout <<"\npost details.....";
        //qDebug()<<reply->readAll();
        if(flag==0)
        {
            postdetails = reply->readAll();
            this->hide();


        }
        else if (flag == 1)
        {
            QByteArray newdetails = reply->readAll();

            QJsonDocument jnewSonDoc(QJsonDocument::fromJson(newdetails));

            QJsonArray jnewArray = jnewSonDoc.array();

            QJsonDocument jSonDoc(QJsonDocument::fromJson(postdetails));
            QJsonArray jArray = jSonDoc.array();
            int newsize = jnewArray.size();
            int i = newsize-1;
            while(i>=0)
            {
                 QJsonObject newobj = jnewArray[i].toObject();
                 jArray.push_front(newobj);
                 i--;


            }
            QJsonDocument doc;
            doc.setArray(jArray);
            postdetails = doc.toJson();


        }
//        else if(flag == -1)
//        {
//            QByteArray newdetails = reply->readAll();
//            QJsonDocument jnewSonDoc(QJsonDocument::fromJson(newdetails));
//            QJsonArray jnewArray = jnewSonDoc.array();
//            QJsonDocument jSonDoc(QJsonDocument::fromJson(postdetails));
//            QJsonArray jArray = jSonDoc.array();
//            int newsize = jnewArray.size();

//            for(int i =0; i < newsize; ++i)
//            {
//                 QJsonObject newobj = jnewArray[i].toObject();
//                 jArray.append(newobj);
//            }
//            QJsonDocument doc;
//            doc.setArray(jArray);
//            postdetails = doc.toJson();
//        }

         SigninWindow::getInstance()->show();
         SigninWindow::getInstance()->DisplayPosts();

    }
}

void MainWindow::slotRequestFinished(QNetworkReply *reply)
{
    if (reply->error() > 0)
    {
      std::cout <<"\nerror reason:" <<reply->errorString().toStdString();
      qDebug()<<reply->readAll();
    }
    else
    {
        std::cout <<"\npost id.....";
        QString success = "success";
        replies = reply->readAll();
        if (replies == success )
        { //compare bytearray to string
            connectToServer();
            qDebug()<< replies;
            ui->login_fail->clear();
        }
        QString fail = "login failed";
        if (replies == fail)
        {

//            QLabel* login_fail = new QLabel(ui->centralWidget);
//            login_fail->setObjectName(QStringLiteral("login_fail"));
//            login_fail->setGeometry(QRect(0, 0, 250, 50));
            ui->login_fail->setText("Please enter correct Login details!");
            ui->login_fail ->raise();
        }
        qDebug()<<replies;
        mfileid = replies;
        ListnerSubject::getInstance()->notify(replies.data());



      //mListnerSubject.notify(ui->mServerStatus->text());
//     static int i = 0;
//      if (i  == 0)
//      {
//          i=0;
          //mPostId = ui->mServerStatus->text();
//      }
//      ++i;
    }
}


//void MainWindow::slotSetProgress(qint64 received, qint64 total)
//{

//}

void MainWindow::PostUserProfile(const QByteArray& data)
{
    QUrl serviceurl = QUrl(mainUrl + "/add/person");
    QNetworkRequest p_request(serviceurl);
    p_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    mNewtworkManager->post(p_request, data);
}

void MainWindow::Postpostinfo(const QByteArray& data)
{

    QUrl serviceurl = QUrl(mainUrl + "/add/post");
    QNetworkRequest p_request(serviceurl);
    p_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    mNetworkReply= mNewtworkManager->post(p_request, data);
}

QString MainWindow::GetCurrentUserName()
{
    return mCurrentUserName;
}

void MainWindow::Postcommentinfo(const QByteArray& data)
{
    QUrl serviceurl = QUrl(mainUrl + "/add/comment");
    QNetworkRequest p_request(serviceurl);
    p_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    mNewtworkManager->post(p_request, data);


}

void MainWindow::Postimageinfo(const QByteArray& data,QFileInfo& filedetails, QString postId)
{

    QUrl serviceurl = QUrl(mainUrl + "/uploadFileForPost?name="+filedetails.fileName()+"&postId="+postId);
    QNetworkRequest p_request(serviceurl);
    p_request.setHeader(QNetworkRequest::ContentTypeHeader, "multipart/form-data");
    p_request.setHeader(QNetworkRequest::ContentTypeHeader,"multipart/form-data; boundary=margin");
    p_request.setRawHeader(QString("Content-Length").toLatin1(), QString::number(data.length()).toLatin1());
    mNewtworkManager->post(p_request, data);
    mPostId = postId;
    //file.close();
}
QString MainWindow::GetPostId()
{
    return mPostId;
}

void MainWindow::connectToServer(){
    QUrl serviceurl;

    if (flag==1)
       {

        QJsonDocument jSonDoc(QJsonDocument::fromJson(postdetails));
        QJsonArray jArray = jSonDoc.array();
        QJsonObject firstpost = jArray.first().toObject();
        QString firstid = firstpost["id"].toString();
        serviceurl = QUrl(mainUrl + "/posts?userName="+mCurrentUserName+"&lastPostId="+firstid);
    }
    else
    {
       serviceurl = QUrl(mainUrl + "/posts?userName="+mCurrentUserName);
    }
    QNetworkRequest p_request(serviceurl);
    p_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    mSignInNetworkManger->get(p_request);
}

//void MainWindow :: getOldPosts()
//{
//    QJsonDocument jSonDoc(QJsonDocument::fromJson(postdetails));
//    QJsonArray jArray = jSonDoc.array();
//   // int postsize = jArray.size();
//    QJsonObject lastpost = jArray.last().toObject();
//    QString lastid = lastpost["id"].toString();
//    QUrl serviceurl = QUrl(mainUrl + "/posts?userName="+mCurrentUserName+"&firstPostId="+lastid);
//    QNetworkRequest p_request(serviceurl);
//    p_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
//    mSignInNetworkManger->get(p_request);
//}






