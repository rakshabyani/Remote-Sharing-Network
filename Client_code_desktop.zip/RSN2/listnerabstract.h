#ifndef LISTNERABSTRACT_H
#define LISTNERABSTRACT_H
#include <QString>

class ListnerAbstract
{
public:
    ListnerAbstract();
    ~ListnerAbstract();
    virtual void notify(QString str) = 0;
};

#endif // LISTNERABSTRACT_H
