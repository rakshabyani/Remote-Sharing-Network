#ifndef SIGNIN
#define SIGNIN
#include <QMainWindow>
#include "ui_signinwindow.h"
#include "uploadwindow.h"
#include "group.h"
//#include "listnersubject.h"
#include <map>
#include <vector>

class SigninWindow : public QMainWindow, public Ui_Sign_in
{
    Q_OBJECT

private:
    SigninWindow(QWidget* wid = 0);
    ~SigninWindow();
public:
    static SigninWindow* getInstance()
    {
        static SigninWindow* instance = NULL;
        if (instance == NULL)
        {
            instance = new SigninWindow();
        }
        return instance;
    }
    void DisplayPosts();

    void senddetails(QString pt,QString fn);
  //  void SetSelectedImagePath(QString path);
    void ReleaseMemory();
   // void SetImageComment(const QString& image_comment);
    void UpdatePosts();
    void AddToOpenedWidgets(QWidget*);
protected:
   // void write_comment(QJsonObject& obj) const;
private slots:
    virtual void group_button_clicked();
    virtual void signin_close();
    virtual void upload_btn_clicked();
    virtual void refresh_btn_clicked();
    virtual void DataSelected(int row, int col);
private :
    UploadWindow* mUploadWindow;
    std::map<QString, std::vector<QString> > mCommentsMap;
    std::vector<QWidget*> mOpenedWidgets;
    QString mImagePath;
    int cursize;
    QString mImageComment;
    //QByteArray mainpostdetails;
};
#endif // SIGNIN

