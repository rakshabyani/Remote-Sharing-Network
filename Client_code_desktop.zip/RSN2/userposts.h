#ifndef USERPOSTS_H
#define USERPOSTS_H
#include "uploadwindow.h"
#include "ui_userposts.h"
#include <QWidget>
#include <vector>
#include <QTextEdit>

namespace Ui {
class UserPosts;
}

class UserPosts : public QWidget
{
    Q_OBJECT

public:
    UserPosts(int row, const QString& filename, const QString& image_comment, const QByteArray& pdetails);
    UserPosts(int row,const QByteArray& pdetails);
    ~UserPosts();





protected :
    void write_comment(QJsonObject& obj) const;
    void UpdatePosts(int row);
private slots:
    virtual void comment_btn_clicked();
    virtual void slotCommentFinished(QNetworkReply *);
    virtual void FileSelected();
private :
    QNetworkAccessManager* mCommentManager;
    QWidget* mPostWidget;
    int size;
    int mRow;
    Ui::UserPosts *ui;
    QString mCurrentPostId;
    std::vector <QString> mNewComments;
    QByteArray commentDetails;
    QString fname;
    QString ptext;
    QString mFileId;
    QByteArray posts;
    QString value;
};

#endif // USERPOSTS_H
