#ifndef SERVERCONNECT
#define SERVERCONNECT
#include <QWidget>
//#include <qnetwork.h>
#include <QtNetwork/QtNetwork>
#include "ui_mainwindow.h"


class Server : public QWidget, public Ui_MainWindow
{
        Q_OBJECT

    public:
         Server();
        ~Server();

private slots:

void slotRequestFinished(QNetworkReply *);
void slotSetProgress(qint64, qint64);
private:
QNetworkAccessManager* manager;
QNetworkRequest request;
QNetworkReply *reply;
};
#endif // SERVERCONNECT

