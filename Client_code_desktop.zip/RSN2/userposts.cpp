#include "userposts.h"
#include "ui_userposts.h"
#include "mainwindow.h"
#include <QLabel>
#include <QJsonDocument>
#include <QJsonObject>
#include <QFile>
#include "ui_uploadwidget.h"
#include <iostream>
#include <QDesktopServices>

//UserPosts::UserPosts(int row, const QString& image_comment, const QString& filename, const QByteArray& pdetails) :
UserPosts::UserPosts(int row,const QByteArray& pdetails) :
//UserPosts::UserPosts(int row):
    ui(new Ui::UserPosts)
{
    ui->setupUi(this);
    mCommentManager = new QNetworkAccessManager(this);
    connect(ui->upload_back,SIGNAL(clicked()),this,SLOT(close()));
    connect(mCommentManager, SIGNAL(finished(QNetworkReply *)),
            SLOT(slotCommentFinished(QNetworkReply *)));

    ui->mCommentWidget->scrollToBottom();
    mRow = row;
    posts = pdetails;
    QJsonDocument jSonDoc(QJsonDocument::fromJson(posts));

    QJsonArray jArray = jSonDoc.array();
    if (mRow < jArray.size())
    {
        QJsonObject jObject;
        jObject = jArray[row].toObject();
        QString id = jObject["id"].toString();
        QUrl serviceurl = QUrl(MainWindow::getInstance()->mainUrl+"/comments/post?id="+id);
        QNetworkRequest c_request(serviceurl);
        c_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
        mCommentManager->get(c_request);

    }
    else{} //for new post

//    {
//        ptext = image_comment;
//        fname = filename;
//        QUrl serviceurl = QUrl(MainWindow::getInstance()->mainUrl+"/comments/post?id="+MainWindow::getInstance()->GetPostId());
//        QNetworkRequest c_request(serviceurl);
//        c_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
//        mCommentManager->get(c_request);
//    }

    connect(ui->comment_btn, SIGNAL(clicked()), this, SLOT(comment_btn_clicked()));
    QFont f( "Arial", 10, QFont::Bold);
    ui->mCommentWidget->setRowCount(1);
    ui->mCommentWidget->setColumnCount(1);




}


void UserPosts::comment_btn_clicked()
{


    ui->mCommentField->setText(ui->mCommentField->toPlainText());



      // QFont f( "Arial", 6, QFont::Bold);
         value = ui->mCommentField->toPlainText();

    mNewComments.push_back(value);
    UpdatePosts(mRow);
    ui->mCommentField->clear();

    QJsonObject jObject;
    write_comment(jObject);
    QJsonDocument saveDoc(jObject);
    MainWindow::getInstance()->Postcommentinfo(saveDoc.toJson());//there is a append function to use

}
void UserPosts::write_comment(QJsonObject &json) const
{
    if(mRow==size)
        json["postid"] = MainWindow::getInstance()->GetPostId();
    else
        json["postid"] = mCurrentPostId;


    json["commentText"] = value;
    json["userName"] = MainWindow::getInstance()->GetCurrentUserName();
}

void UserPosts::UpdatePosts(int row)
{

    QFont f( "Comic Sans MS", 10, QFont::Bold);
     QFont n( "Comic Sans MS", 10, QFont::Normal);

    QJsonDocument jSonDoc(QJsonDocument::fromJson(posts));
    QJsonDocument jSoncom(QJsonDocument::fromJson(commentDetails));
    QJsonArray jCarray = jSoncom.array();

    QJsonArray jArray = jSonDoc.array();
    size = jArray.size();
    int x = 10;
    int y = 10;
    int width = 100;
    int height = 20;
     mPostWidget= new QWidget();
     mPostWidget->setGeometry(QRect(0, 0, 100, 100));
    if (row < size)
    {
        QJsonObject jObject;
        jObject = jArray[row].toObject();
        //mPostWidget = post1;
        // mPostWidget->setObjectName(QStringLiteral("post1"));

        mCurrentPostId = jObject["id"].toString();
        QLabel* mUserName = new QLabel(mPostWidget);
        mUserName->setFont(f);
        mUserName->setObjectName(QStringLiteral("mUserName"));
        mUserName->setGeometry(QRect(x, y, width, height));
        mUserName->setText("User Name :");
        QLabel*mName  = new QLabel(mPostWidget);
        mName->setFont(n);
        mName->setObjectName(QStringLiteral("mUserName"));
        mName->setGeometry(QRect(x+width+1, y, width, height));
        mName->setText(jObject["userName"].toString());
        QLabel* mText = new QLabel(mPostWidget);
        mText->setFont(f);
        mText->setObjectName(QStringLiteral("mUserName"));
        mText->setGeometry(QRect(x, y += (height+1), width, height));
        mText->setText("Post Text :");
        QLabel* mPostText = new QLabel(mPostWidget);
        mPostText->setFont( n);
        mPostText->setObjectName(QStringLiteral("mPostText"));
        mPostText->setGeometry(QRect(x+width+1, y, 219, height));
        mPostText->setText(jObject["postText"].toString());

        QJsonArray farray = jObject["files"].toArray();
        for(int fsize=0;fsize<farray.size();++fsize)
        {
            QJsonObject obj = farray[fsize].toObject();

            QPushButton* mPostData = new QPushButton(mPostWidget);
            mPostData->setObjectName(QStringLiteral("mPostData"));
            mPostData->setGeometry(QRect(x+width, y += (height+2), width+50, height+5));
            // mPostData->setGeometry(QRect(10, 30+fsize*10, 100, 100));
            mPostData->setFont( f);
            mPostData->setText(obj["fileName"].toString());
            mFileId = obj["fileId"].toString();
            connect(mPostData, SIGNAL(clicked()), this, SLOT(FileSelected()));
        }
        //QJsonArray carray = jCobj["comments"].toArray();
        int csize = jCarray.size();

        for ( int i= 0; i < csize; i++) {
            QJsonObject obj = jCarray[i].toObject();

            QString utext = obj["userName"].toString();
            QLabel* ut = new QLabel(mPostWidget);
            QFont fuser( "Comic Sans MS", 7, QFont::StyleItalic);
            ut->setFont(fuser);
            ut->setObjectName(QStringLiteral("userName"));
            ut->setText(utext);
            ut->setGeometry(QRect(x, y += (height+1), width, height+10));
            QString ctext = obj["commentText"].toString();
            QLabel* ct = new QLabel(mPostWidget);
            ct->setFont( f);
            ct->setObjectName(QStringLiteral("commentText"));
            ct->setText(ctext);
            ct->setGeometry(QRect(x, y += (height+1), 320, height));

        }

        for (unsigned int i = 0; i < mNewComments.size(); ++i)
        {
            QString value = mNewComments.at(i);
            QLabel* mNewComments_Label = new QLabel(mPostWidget);
            mNewComments_Label->setObjectName(QStringLiteral("mNewComments_Label"));
            mNewComments_Label->setGeometry(QRect(x, y += (height+1), 320, height));
            mNewComments_Label->setFont(f);
            mNewComments_Label->setText(value);
        }


    }

    mPostWidget->raise();
    ui->mCommentWidget->setRowHeight(0, ui->mCommentWidget->height());
    ui->mCommentWidget->setColumnWidth(0, ui->mCommentWidget->width());
    ui->mCommentWidget->setCellWidget(0, 0, mPostWidget);
}

UserPosts::~UserPosts()
{
    delete ui;
}

void UserPosts::slotCommentFinished(QNetworkReply * reply){
    if (reply->error() > 0) {
        std::cout <<"\nerror reason:" <<reply->errorString().toStdString();

    }
    else
    {
        commentDetails = reply->readAll();
        UpdatePosts(mRow);
    }
}

void UserPosts::FileSelected()
{
    QDesktopServices::openUrl(QUrl(MainWindow::getInstance()->mainUrl+"/download?fileId="+mFileId));
}


