#include "group.h"
#include "grouposts.h"
#include "ui_group.h"
#include <iostream>
#include "creategroup.h"
#include "signin.h"
#include "mainwindow.h"


Group::Group()
{
    setupUi(this);
    mGroupContactManager = new QNetworkAccessManager(this);
    connect(group_back,SIGNAL(clicked()),this,SLOT(grp_back_btn()));
    connect(mGrpContact, SIGNAL(cellClicked(int,int)), this, SLOT(GDataSelected(int, int)));
    connect(mGroupContactManager, SIGNAL(finished(QNetworkReply *)),
            SLOT(slotcontactFinished(QNetworkReply *)));
    connect(create_grp,SIGNAL(clicked()),this,SLOT(create_grp_btn()));
    connect(grp_refresh,SIGNAL(clicked()),this,SLOT(grp_refresh_clicked()));
    connectToGrpServer();


}

Group::~Group()
{

}

void Group::grp_back_btn()
{
    this->close();
}
void Group::GDataSelected(int row, int col)
{
    QJsonDocument jSonDoc(QJsonDocument::fromJson(gContacts));
    QJsonArray jArray = jSonDoc.array();
    QString grpsel = jArray[row].toString();
    grouposts *obj = new grouposts(grpsel);
    SigninWindow::getInstance()->AddToOpenedWidgets(obj);
    obj->show();
    qDebug()<<row<<""<<col;
}
void Group ::slotcontactFinished(QNetworkReply * reply)
{
    if (reply->error() > 0)
    {
        std::cout <<"\nerror reason:" <<reply->errorString().toStdString();
    }
    else
    {
        gContacts = reply->readAll();
        DisplayContact();
    }
}
void Group::DisplayContact()
{
    QFont f("Comic Sans MS",9,QFont::Bold);
    QFont n("Comic Sans MS",9,QFont::Normal);
    QJsonDocument jSonDoc(QJsonDocument::fromJson(gContacts));
    QJsonArray jArray = jSonDoc.array();
    int gsize = jArray.size();
    mGrpContact->setRowCount(gsize);
    mGrpContact->setColumnCount(1);
    mGrpContact->setColumnWidth(0, mGrpContact->width());
    for (int i = 0; i < gsize;++i)
    {
        int x=10;
        int y=10;
        int width=100, height = 20 ;
        QWidget* post1 = new QWidget();
        post1->setObjectName(QStringLiteral("post1"));
        post1->setGeometry(QRect(10, 10, 150, 50));
        QLabel* g1= new QLabel(post1);
        g1->setFont( f);
        g1->setObjectName(QStringLiteral("g1"));
        g1->setGeometry(QRect(x, y, width, height));
        g1->setText("Group Name :");
        QLabel* g2 = new QLabel(post1);
        g2->setFont( n);
        g2->setObjectName(QStringLiteral("g2"));
        g2->setGeometry(QRect(x+width+1, y, width, height));
        g2->setText(jArray[i].toString());
        post1->raise();
        mGrpContact->setRowHeight(i, post1->height());
        mGrpContact->setCellWidget(i, 0, post1);
    }

}

void Group :: create_grp_btn(){
    creategroup* group = new creategroup;
    SigninWindow::getInstance()->AddToOpenedWidgets(group);
    group->show();
}
void Group :: grp_refresh_clicked()
{
    connectToGrpServer();
}

void Group ::connectToGrpServer()
{
    QUrl serviceurl = QUrl(MainWindow::getInstance()->mainUrl+"/userGroup/users?userNames="+MainWindow::getInstance()->GetCurrentUserName());
    QNetworkRequest g_request(serviceurl);
    g_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    mGroupContactManager->get(g_request);
}
