#ifndef GROUP
#define GROUP
#include <QtNetwork/QtNetwork>
#include "ui_group.h"



class Group : public QWidget,public Ui_Group
{
    Q_OBJECT
public:

    Group();
    ~Group();
private :
    QNetworkAccessManager* mGroupContactManager;
    QByteArray gContacts;
    void DisplayContact();
    void connectToGrpServer();
private slots:
    virtual void grp_back_btn();
    virtual void create_grp_btn();
    virtual void slotcontactFinished(QNetworkReply *);
    virtual void GDataSelected(int row, int col);
    virtual void grp_refresh_clicked();
};
#endif // GROUP

