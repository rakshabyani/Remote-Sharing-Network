#include "creategroup.h"
#include "ui_creategroup.h"
#include <iostream>
#include "mainwindow.h"


creategroup::creategroup()
{
    setupUi(this);
    contactflag =0;
    mUserContactManager = new QNetworkAccessManager(this);
    connect(save_grp,SIGNAL(clicked()),this,SLOT(new_grp_create()));
    connect(Cancel,SIGNAL(clicked()),this,SLOT(close()));
    connect(mUserContactManager, SIGNAL(finished(QNetworkReply *)),
            SLOT(slotcontactFinished(QNetworkReply *)));
    QUrl serviceurl = QUrl(MainWindow::getInstance()->mainUrl+"/users");
    QNetworkRequest u_request(serviceurl);
    u_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    mUserContactManager->get(u_request);
}

creategroup::~creategroup()
{

}
void creategroup :: new_grp_create(){
    QJsonObject jobj;
    jobj["groupName"] = group_name->text();
    QJsonArray userNames;
    for (unsigned int i =0;i<mCheckBoxes.size();i++)
    {

        QJsonValue abc;
        if(mCheckBoxes.at(i)->checkState() == Qt::Checked)
        {
            abc = mCheckBoxes.at(i)->text();
            userNames.append(abc);
        }
        userNames.append(MainWindow::getInstance()->GetCurrentUserName());
    }
    jobj["userNames"] = userNames;
    QJsonDocument saveDoc(jobj);
    QUrl serviceurl = QUrl(MainWindow::getInstance()-> mainUrl + "/add/group");
    QNetworkRequest p_request(serviceurl);
    p_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    mUserContactManager->post(p_request,saveDoc.toJson());



}
void creategroup :: Displayusers()
{

    QJsonDocument jSonDoc(QJsonDocument::fromJson(uContacts));

    QJsonArray jArray = jSonDoc.array();
    usize = jArray.size();

    userwidget->setRowCount(usize-1);
    userwidget->setColumnCount(1);
    userwidget->setColumnWidth(0, userwidget->width());
    int row = 0;
    for (int i = 0; i <usize;++i)
    {


        if(jArray[i].toString() != MainWindow::getInstance()->GetCurrentUserName())
        {

            int x=10;
            int y=10;
            int width=100, height = 20 ;
            QWidget* post1 = new QWidget();
            post1->setObjectName(QStringLiteral("post1"));
            post1->setGeometry(QRect(10, 10, 150, 50));

            QCheckBox* g2 = new QCheckBox(post1);

            g2->setObjectName(QStringLiteral("g2"));
            g2->setGeometry(QRect(x, y, width, height));
            g2->setText(jArray[i].toString());
            qDebug()<<jArray[i].toString();
            mCheckBoxes.push_back(g2);
            post1->raise();
            userwidget->setRowHeight(row, post1->height());
            userwidget->setCellWidget(row, 0, post1);
            row++;
        }
    }
}

void creategroup :: slotcontactFinished(QNetworkReply *reply )
{
    if (reply->error() > 0) {
        std::cout <<"\nerror reason:" <<reply->errorString().toStdString();

    }
    else
    {
        if(contactflag ==0)
        {
            uContacts = reply->readAll();
            Displayusers();
            contactflag =1;
        }
        else
        {
            QByteArray replies = reply->readAll();
            qDebug()<<replies;
            this->close();
        }



    }
}
