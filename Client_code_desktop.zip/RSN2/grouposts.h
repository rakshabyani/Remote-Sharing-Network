#ifndef GROUPOSTS_H
#define GROUPOSTS_H
#include <QMainWindow>
#include <QWidget>
#include "ui_grouposts.h"
#include <QtNetwork/QtNetwork>


class grouposts : public QWidget, public Ui_grouposts
{
    Q_OBJECT

public:
    grouposts(QString& group_sel);
    ~grouposts();

private:
    QNetworkAccessManager* mGroupManager;
    QByteArray groupDetails;
    void DisplayGroup();
    QString group_selected;
    void connectToGPserver();
    int grefreshflag;

private slots:
    virtual void slotGroupFinished(QNetworkReply *);
    virtual void back_btn_clicked();
    virtual void DataSelected(int row, int col);
    virtual void grefresh_btn_clicked();

};

#endif // GROUPOSTS_H
