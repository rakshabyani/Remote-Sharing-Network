
#include "signup.h"
#include <QMainWindow>
#include <QUuid>
#include <QFile>
#include <QJsonDocument>
#include "mainwindow.h"

SignupWindow::SignupWindow(QWidget *parent)
{
    setupUi(this);
    connect(submit_btn, SIGNAL(clicked()), this, SLOT(submit_btn_clicked()));
    connect(cancel_btn, SIGNAL(clicked()), this, SLOT(cancel_btn_clicked()));

}

SignupWindow::~SignupWindow()
{

}

void SignupWindow::submit_btn_clicked()
{
        QJsonObject jObject;
        write_json(jObject);
        QJsonDocument saveDoc(jObject);
        MainWindow::getInstance()->PostUserProfile(saveDoc.toJson());
        this->close();
}

void SignupWindow::cancel_btn_clicked()
{

    this->close();
}

void SignupWindow::write_json(QJsonObject& obj)
{
    obj["firstName"] = mFirstName->text();
    obj["lastName"] = mLastName->text();
    obj["userName"] = mUserName->text();
    obj["password"] = mPassword->text();
}
