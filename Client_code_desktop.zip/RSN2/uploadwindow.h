#ifndef UPLOADWINDOW
#define UPLOADWINDOW

#include "ui_uploadwidget.h"
#include <QJsonObject>
#include <QtNetwork/QtNetwork>
#include "ui_signinwindow.h"
//#include "signin.h"
#include <qobject.h>
//#include "listnersubject.h"
//class SigninWindow;
#include "listnerabstract.h"
class UploadWindow : public QWidget, public Ui_Upload, public ListnerAbstract
{
  Q_OBJECT
public:
   UploadWindow();
    ~UploadWindow();
    QString getSharedFilePath();
    //void setSignInWindow(SigninWindow obj);
   virtual void notify(QString str);

protected:
    void write(QJsonObject& obj) const;
    //void write_post();

private slots:
  virtual void browse_btn_clicked();
    virtual void ok_btn_clicked();
    virtual void cancel_btn_clicked();
    virtual void contact_clicked(int,int);
    virtual void slotcontactFinished(QNetworkReply *);
    //virtual void FileSelected(const QString& file_name);
private:
    QNetworkAccessManager* mGroupContactManager;
   QByteArray gContacts;
   //void AppendPost(QJsonObject &obj);
   void DisplayContact();
    QString cdata;
   QString mFilePath;
   //ListnerSubject mSubject;
  // Ui_Sign_in mSignInwin;


};
#endif // UPLOADWINDOW

