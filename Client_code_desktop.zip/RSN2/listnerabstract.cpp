#include "listnerabstract.h"

ListnerAbstract::ListnerAbstract()
{

}

ListnerAbstract::~ListnerAbstract()
{

}

