#include "listnersubject.h"

ListnerSubject::ListnerSubject()
{

}

ListnerSubject::~ListnerSubject()
{

}

void ListnerSubject::attach(ListnerAbstract* obj)
{
    mListners.push_back(obj);
}

void ListnerSubject::detach()
{
    mListners.clear();
}

void ListnerSubject::notify(QString text)
{
    for (int i = 0; i < mListners.size(); ++i)
    {
        ListnerAbstract* obj = mListners.at(i);
        if (obj)
            obj->notify(text);
    }
}
