#ifndef SIGNUP
#define SIGNUP

#include "signin.h"
#include "ui_signupwidget.h"
#include <fstream>
#include <QJsonObject>
#include <QtNetwork/QtNetwork>

class SignupWindow : public QWidget, public Ui_Signup_Form
{
   Q_OBJECT
public:
   SignupWindow(QWidget* wid = 0);
    ~SignupWindow();

protected:
    void write_json(QJsonObject& obj);

private slots:
  virtual void submit_btn_clicked();
   virtual void cancel_btn_clicked();

private:

};

#endif // SIGNUP

