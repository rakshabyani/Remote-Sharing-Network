
#include "signin.h"
#include "uploadwindow.h"
#include "ui_uploadwidget.h"
#include <QFileDialog>
#include <QJsonDocument>
#include "ui_signinwindow.h"
#include "mainwindow.h"
#include <unistd.h>
#include <iostream>

UploadWindow::UploadWindow()
{
    setupUi(this);
    mGroupContactManager = new QNetworkAccessManager(this);
    connect(browse_btn, SIGNAL(clicked()), this, SLOT(browse_btn_clicked()));
    connect(ok_upload, SIGNAL(clicked()), this, SLOT(ok_btn_clicked()));
    connect(cancel_upload, SIGNAL(clicked()), this, SLOT(cancel_btn_clicked()));
    connect (contacts,SIGNAL(cellClicked(int,int)),this,SLOT(contact_clicked(int,int)));

    // connect(QFileDialog, SIGNAL(fileSelected(QString&)), this, SLOT(FileSelected(QString&)));
    connect(mGroupContactManager, SIGNAL(finished(QNetworkReply *)),
            SLOT(slotcontactFinished(QNetworkReply *)));
    QUrl serviceurl = QUrl(MainWindow::getInstance()->mainUrl+"/userGroup/users?userNames="+MainWindow::getInstance()->GetCurrentUserName());
    QNetworkRequest g_request(serviceurl);
    g_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    mGroupContactManager->get(g_request);

    ListnerSubject::getInstance()->attach(this);


}

UploadWindow::~UploadWindow()
{


}

void UploadWindow::browse_btn_clicked()
{
    mFilePath=QFileDialog::getOpenFileName(this, tr("Select File"), "", tr("files(**)"));

    mUploadPath->setPixmap(QPixmap(mFilePath));
    mUploadPath->setScaledContents(true);
}

void UploadWindow::ok_btn_clicked()//send post details here
{

    QJsonObject jObject;
    write(jObject);
    QJsonDocument saveDoc(jObject);
    MainWindow::getInstance()->Postpostinfo(saveDoc.toJson());
   // qDebug()<<MainWindow::getInstance()->GetPostId();


 //   MainWindow::getInstance()->connectToServer();
   // SigninWindow::getInstance()->SetSelectedImagePath(mFilePath);
  //  SigninWindow::getInstance()->SetImageComment(mPostText->text());
    if (cdata.isEmpty()){
        //SigninWindow::getInstance()->UpdatePosts();
    }
    //(might need only this)
    SigninWindow::getInstance()->senddetails(mPostText->text(),mFilePath);

    //SigninWindow::getInstance()->DisplayPosts();


}
void UploadWindow::write(QJsonObject &json) const
{

    json["postText"]= mPostText->text();
    json["userName"] = MainWindow::getInstance()->GetCurrentUserName();
    if (cdata.isEmpty()){
       // SigninWindow :: getInstance()->newGroup = 1;
    }

    else
    {
        json ["groupName"] = cdata;
    }
}
void UploadWindow::cancel_btn_clicked()
{
   SigninWindow::getInstance()->ReleaseMemory();
}

//void UploadWindow::FileSelected(const QString& file_name)
//{
//    //std::out <<"file slected..."<<file_name.toStdString();
//}

QString UploadWindow::getSharedFilePath()
{
    return mFilePath;
}

void UploadWindow::notify(QString str)
{
    //std::cout <<"\nnotification received...";
    QByteArray data;


    QFile file(getSharedFilePath());
    QFileInfo filedet(getSharedFilePath());
    if(filedet.suffix()=="jpg")
     data.insert(0,"--margin\r\nContent-Disposition: form-data; name=\"file\"; filename="+filedet.fileName()+"\r\nContent-Type : image/jpeg\r\n\r\n");
   else
        data.insert(0,"--margin\r\nContent-Disposition: form-data; name=\"file\"; filename="+filedet.fileName()+"\r\n\r\n\r\n");
    // qDebug() << filedet.fileName();
      if (!file.open(QIODevice::ReadOnly)){
        qDebug() << "QFile Error: File not found!";
          return;
      }
      else
      { qDebug() << "File found, proceed as planned"; }



    data.append(file.readAll());
    data.append("\r\n--margin--\r\n");
    //get id and send with image
     MainWindow::getInstance()->Postimageinfo(data,filedet, str);
     SigninWindow::getInstance()->ReleaseMemory();
}
void UploadWindow::contact_clicked(int row, int col){
   //check is row is less than json datas size..
    // access that rows data and set cdata
    QJsonDocument jSonDoc(QJsonDocument::fromJson(gContacts));

    QJsonArray jArray = jSonDoc.array();
    if(row<jArray.size()){
    cdata = jArray[row].toString();
    }
    qDebug()<<cdata<<""<<col;
}

//void UploadWindow::SetListnerSubject(ListnerSubject obj)
//{

//}

//void UploadWindow::setSignInWindow(SigninWindow obj)
//{
//  // mSignInwin = obj;
//}
void UploadWindow ::slotcontactFinished(QNetworkReply * reply){
    if (reply->error() > 0) {
        std::cout <<"\nerror reason:" <<reply->errorString().toStdString();

    }
    else
    {
        gContacts = reply->readAll();
        DisplayContact();

    }
}
void UploadWindow::DisplayContact(){
    QJsonDocument jSonDoc(QJsonDocument::fromJson(gContacts));

    QJsonArray jArray = jSonDoc.array();
    int gsize = jArray.size();
    contacts->setRowCount(gsize);



    contacts->setColumnCount(1);
    contacts->setColumnWidth(0, contacts->width());
    for (int i = 0; i < gsize;++i)
    {
        int x=10;
        int y=10;
        int width=100, height = 20 ;

        QWidget* post1 = new QWidget();
        post1->setObjectName(QStringLiteral("post1"));
        post1->setGeometry(QRect(10, 10, 150, 50));
        QLabel* g1= new QLabel(post1);
       // mName->setFont( f);
        g1->setObjectName(QStringLiteral("g1"));
        g1->setGeometry(QRect(x, y, width, height));
        g1->setText("Group Name :");
        QLabel* g2 = new QLabel(post1);
        //g2->setFont( f);
        g2->setObjectName(QStringLiteral("g2"));
        g2->setGeometry(QRect(x+width+1, y, width, height));
        g2->setText(jArray[i].toString());


        post1->raise();
        contacts->setRowHeight(i, post1->height());
        contacts->setCellWidget(i, 0, post1);
    }
}
//void UploadWindow :: write_post(){
//    QJsonObject obj;
//    obj["postText"]= mPostText->text();
//    obj["userName"] = MainWindow::getInstance()->GetCurrentUserName();
//    obj ["Id"] = MainWindow::getInstance()->GetPostId();

//    AppendPost(obj);
//    // array obj ["files"]


//}
//void UploadWindow :: AppendPost(QJsonObject &obj){
//    QJsonDocument jSonDoc(QJsonDocument::fromJson(MainWindow::getInstance()->postdetails));

//    QJsonArray jArray = jSonDoc.array();
//    int size = jArray.size();
//    jArray.append(obj);
//}
