#include "grouposts.h"
#include "ui_grouposts.h"
#include "mainwindow.h"
#include <iostream>
#include "signin.h"

grouposts::grouposts(QString& group_sel)//mostly pass the name as a parameter from previous class


{
    setupUi(this);
    mGroupManager = new QNetworkAccessManager(this);
    connect(grp_post_back,SIGNAL(clicked()),this,SLOT(back_btn_clicked()));
    connect(mGroupWidget, SIGNAL(cellClicked(int,int)), this, SLOT(DataSelected(int, int)));
    connect(mGroupManager, SIGNAL(finished(QNetworkReply *)),
            SLOT(slotGroupFinished(QNetworkReply *)));
    connect(gpost_refresh,SIGNAL(clicked()),this,SLOT(grefresh_btn_clicked()));
    grefreshflag = 0;
    group_selected = group_sel;
    connectToGPserver();




}

grouposts::~grouposts()
{

}

void grouposts::back_btn_clicked(){
    this->close();
}
void grouposts::DataSelected(int row, int col){

    UserPosts *obj = new UserPosts(row,groupDetails);
    SigninWindow::getInstance()->AddToOpenedWidgets(obj);
    obj->show();
    qDebug()<<row<<""<<col;

}
void grouposts::DisplayGroup(){
    QFont f( "Comic Sans MS", 9, QFont::Bold);
    QFont n( "Comic Sans MS", 9, QFont::Normal);

    QJsonDocument jSonDoc(QJsonDocument::fromJson(groupDetails));
    QJsonArray jArray = jSonDoc.array();
    int size = jArray.size();
    QJsonObject jObject;
    mGroupWidget->setRowCount(size);
    mGroupWidget->setColumnCount(1);
    mGroupWidget->setColumnWidth(0,mGroupWidget->width());
    for (int i = 0; i < size; ++i)
    {
        int x=10;
        int y=10;
        int width=100, height = 20 ;
        jObject = jArray[i].toObject();
        QWidget* post1 = new QWidget();
        post1->setObjectName(QStringLiteral("post1"));
        post1->setGeometry(QRect(20, 50, 161, 111));
        QLabel* mName = new QLabel(post1);
        mName->setFont( f);
        mName->setObjectName(QStringLiteral("mUserName"));
        mName->setGeometry(QRect(x, y, width, height));
        mName->setText("User Name :");
        QLabel* mUserName = new QLabel(post1);
        mUserName->setFont( n);
        mUserName->setObjectName(QStringLiteral("mUserName"));
        mUserName->setGeometry(QRect(x+width+1, y, width, height));
        mUserName->setText(jObject["userName"].toString());
        QLabel* mPost= new QLabel(post1);
        mPost->setFont( f);
        mPost->setObjectName(QStringLiteral("mPName"));
        mPost->setGeometry(QRect(x, y += height+1 , width, height));
        mPost->setText("Post Text :");
        QLabel* mPostText = new QLabel(post1);
        mPostText->setFont( n);
        mPostText->setObjectName(QStringLiteral("mPostText"));
        mPostText->setGeometry(QRect(x+width+1, y, 219, height));
        mPostText->setText(jObject["postText"].toString());
        QLabel* mFile= new QLabel(post1);
        mFile->setFont( f);
        mFile->setObjectName(QStringLiteral("mFName"));
        mFile->setGeometry(QRect(x, y+= (height+1), width, height));
        mFile->setText("File Name :");
        QLabel* mPostData = new QLabel(post1);
        mPostData->setObjectName(QStringLiteral("mPostData"));
        mPostData->setGeometry(QRect(x+width+1, y, width, height));
        QJsonArray array = jObject["files"].toArray();
        for(int fsize=0;fsize<array.size();++fsize)
        {
            QJsonObject obj = array[fsize].toObject();
            mPostData->setFont( n);
            mPostData->setText(obj["fileName"].toString());
        }
        QLabel* date = new QLabel(post1);
        date->setFont( f);
        date->setObjectName(QStringLiteral("mDate"));
        date->setGeometry(QRect(x, y+= (height+1), width, height));
        date->setText("Date :");
        QLabel* pdate = new QLabel(post1);
        pdate->setFont( n);
        pdate->setObjectName(QStringLiteral("mPDate"));
        pdate->setGeometry(QRect(x+width+1, y, width+50, height));
        pdate->setText(jObject["date"].toString());

        post1->raise();
        mGroupWidget->setRowHeight(i, post1->height());
        mGroupWidget->setCellWidget(i, 0, post1);
    }
}


void grouposts::slotGroupFinished(QNetworkReply * reply){
    if (reply->error() > 0)
    {
        std::cout <<"\nerror reason:" <<reply->errorString().toStdString();
    }
    else
    {
        if(grefreshflag == 0)
        {
            groupDetails = reply->readAll();

         }
        else
        {
            QByteArray newdetails = reply->readAll();

            QJsonDocument jnewSonDoc(QJsonDocument::fromJson(newdetails));
            QJsonArray jnewArray = jnewSonDoc.array();
            QJsonDocument jSonDoc(QJsonDocument::fromJson(groupDetails));
            QJsonArray jArray = jSonDoc.array();
            int newsize = jnewArray.size();
            int i = newsize-1;
            while(i>=0)
            {
                 QJsonObject newobj = jnewArray[i].toObject();
                 jArray.push_front(newobj);
                 i--;
            }
            QJsonDocument doc;
            doc.setArray(jArray);
            groupDetails = doc.toJson();
        }
        DisplayGroup();
    }
}

void grouposts :: grefresh_btn_clicked()
{
    grefreshflag = 1;
    connectToGPserver();
}

void grouposts :: connectToGPserver()
{
    QUrl serviceurl ;
    if(grefreshflag == 0)
    {
       serviceurl = QUrl(MainWindow::getInstance()->mainUrl+"/userGroup/posts?groupName="+group_selected);
    }
    else
    {
        QJsonDocument jSonDoc(QJsonDocument::fromJson(groupDetails));
        QJsonArray jArray = jSonDoc.array();
        QJsonObject firstpost = jArray.first().toObject();
        QString firstid = firstpost["id"].toString();
        serviceurl = QUrl(MainWindow::getInstance()->mainUrl+"/userGroup/posts?groupName="+group_selected+"&lastPostId="+firstid);
    }
    QNetworkRequest g_request(serviceurl);
    g_request.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    mGroupManager->get(g_request);
}
