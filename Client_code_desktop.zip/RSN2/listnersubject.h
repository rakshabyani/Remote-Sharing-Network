#ifndef LISTNERSUBJECT_H
#define LISTNERSUBJECT_H
#include <QString>
#include "listnerabstract.h"
#include <vector>
class ListnerSubject
{
    ListnerSubject();
    ~ListnerSubject();
public:
   static ListnerSubject* getInstance()
   {
      static ListnerSubject* instance = NULL;
      if (!instance)
      {
          instance = new ListnerSubject();
      }
      return instance;
   }

    void attach(ListnerAbstract* obj);
    void detach();
    void notify(QString text);

private:
    std::vector<ListnerAbstract*> mListners;
};

#endif // LISTNERSUBJECT_H
