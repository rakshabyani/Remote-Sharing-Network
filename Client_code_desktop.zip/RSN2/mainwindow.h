#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "signup.h"
#include "signin.h"
#include <QtNetwork/QtNetwork>
#include <QMainWindow>
#include "listnersubject.h"
#include "userposts.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

private:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

public:
    static MainWindow* getInstance()
    {
        static MainWindow* instance = NULL;
        if (instance == NULL)
        {
            instance = new MainWindow();
        }
        return instance;
    }

    void PostUserProfile(const QByteArray& data);
    void Postpostinfo(const QByteArray& data);
    void Postcommentinfo(const QByteArray& data);
    void Postimageinfo(const QByteArray& data,QFileInfo& filedetails, QString postId);
    QString GetCurrentUserName();
    QString GetPostId();

private slots:
    virtual void signin_btn_clicked();
    virtual void signup_btn_clicked();
    //virtual  void on_close_clicked();
    void slotRequestFinished(QNetworkReply *);
    void slotpostrequest(QNetworkReply *);

public:
    int flag ;
    QByteArray postdetails;
    QByteArray replies;
    QString mfileid;
    QString mainUrl;
    void connectToServer();
    void getOldPosts();


private:
    Ui::MainWindow *ui;
    SignupWindow mSignUpWin;
    QNetworkAccessManager* mNewtworkManager;
    QNetworkAccessManager* mSignInNetworkManger;
    QNetworkRequest mNetworkRequest;
    QNetworkReply* mNetworkReply;
    QString mCurrentUserName;
    QString mCurrentPassword;
    QString mPostId;
    QByteArray newdetails;
    void checksign();
    //ListnerSubject mListnerSubject;



};

#endif // MAINWINDOW_H

